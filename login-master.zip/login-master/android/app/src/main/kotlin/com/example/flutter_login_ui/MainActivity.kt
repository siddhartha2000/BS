package com.example.flutter_login_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
